import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./App.css";

const App = () => (
  <div className="App mine">
    <Container fluid>
      <Row>
        <Col sm={3}>
          <h5>
            Get The App <i className="fab fa-apple"></i>
          </h5>
          <h5>Follow Us</h5>
          <div className="footer-social">
            <ul>
              <li>
                <a href="#">
                  <i className="fab fa-facebook"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fab fa-twitter"></i>
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="fab fa-instagram"></i>
                </a>
              </li>
            </ul>
          </div>
        </Col>

        <Col sm={2} className="second-social">
          <ul>
            <li>
              <a href="#">How it Works</a>
            </li>
            <li>
              <a href="#">Press</a>
            </li>
            <li>
              <a href="#">For art & Trade</a>
            </li>
            <li>
              <a href="#">The Shop</a>
            </li>
          </ul>
        </Col>

        <Col sm={2} className="second-social">
          <ul>
            <li>
              <a href="#">Stores</a>
            </li>
            <li>
              <a href="#">Pricing</a>
            </li>
            <li>
              <a href="#">Reviews</a>
            </li>
            <li>
              <a href="#">Careers</a>
            </li>
          </ul>
        </Col>
        <Col sm={2} className="second-social">
          <ul>
            <li>
              <a href="#">About Us</a>
            </li>
            <li>
              <a href="#">Gift Card</a>
            </li>
            <li>
              <a href="#">Contact Us</a>
            </li>
          </ul>
        </Col>
        <Col sm={2} className="second-social">
          <ul>
            <li>
              <a href="#">Terms of Service</a>
            </li>
            <li>
              <a href="#">Privacy Policy</a>
            </li>
            <li>
              <a href="#">Accesiblity</a>
            </li>
            <li>
              <a href="#">Sitemap</a>
            </li>
          </ul>
        </Col>
      </Row>
      <div className="footer-legal"> © 2020 Index</div>
    </Container>
  </div>
);

export default App;
